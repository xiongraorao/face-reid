<?php
	(isSet($_GET["clusterId"]))?$isOneCluster=true:$isOneCluster=false;
?>
<html>
<head>
	<title>clustering</title>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
	<!--<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">-->
	<style>
		body{
			padding:0 20px 20px 20px;
		}
		#clustering-result-div{
			width:100%;
			height:880px;
			overflow-y:auto;
			padding-bottom:20px;
		}
		.one-cluster-div{
		}
		.cluster-name-a{
			font-size:18px;
		}
		.one-cluster-images-div{
			padding:0 10px 0 10px;
		}
		.one-cluster-images-div img{
			margin:6px 6px 0 0;
			height:150px;
		}
	</style>
</head>
<body>
	<h2>Clusters</h2>
	<div id="clustering-result-div"></div>
	
	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
	<!--<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>-->
	<script type="text/javascript">
		var clusterIds;//所有的类
		var onceClustersNum = 10;//一次显示类的个数
		var fileName = "clustering.php";
		<?php if($isOneCluster){//显示一个类时 ?>
			var isOneCluster = true;
		<?php }else{//显示所有类时 ?>
			var isOneCluster = false;
		<?php } ?>

		/* 类点击函数 */
		function clusterClickFunc(obj){
			//var clusterId = $(obj).html().split(" ")[1];
			//alert(clusterId);
		}
		/* 显示类函数 */
		function showClusters(dataArr){
			var preClusterId = "",curClusterId = "", imgSrc = "", oneClusterDiv="", oneClusterImagesDiv="", imgsNum = -1, saveImgsNum = 0, maxImgsNum = 999999;
                        for(var i = 0; i < dataArr.length; i++){
                                curClusterId = dataArr[i].split(" ")[0];
                                imgSrc = dataArr[i].split(" ")[1];
                                if(curClusterId != preClusterId){
					var num = 0;
					(saveImgsNum > imgsNum)?num=saveImgsNum:num=imgsNum;
					if(!isOneCluster && oneClusterImagesDiv) $(oneClusterImagesDiv).append($("<span>（"+num+"张预览图，可点击类 id 查看详情）</span>"));
                                        if(oneClusterDiv) $("#clustering-result-div").append(oneClusterDiv);
					imgsNum = 0;
					saveImgsNum = 0;
                                        oneClusterDiv = $("<div class='one-cluster-div'><p><a class='cluster-name-a' title='点击查看类详情' onclick='clusterClickFunc(this)' href='"+fileName+"?clusterId="+curClusterId+"' target='_blank'>Cluster: "+curClusterId+"</a></p></div>");
                                        oneClusterImagesDiv = $("<div class='one-cluster-images-div'></div>");
                                        $(oneClusterDiv).append(oneClusterImagesDiv);
                                }
				if(imgsNum >= maxImgsNum){
					saveImgsNum = imgsNum;
					imgsNum = -1;
				}
				if(imgsNum == -1 && !isOneCluster) continue;
                                $(oneClusterImagesDiv).append($("<img src='"+imgSrc+"' />"));
                                preClusterId = curClusterId;
				imgsNum ++;
                        }
			var num = 0;
			(saveImgsNum > imgsNum)?num=saveImgsNum:num=imgsNum;
			if(!isOneCluster && oneClusterImagesDiv) $(oneClusterImagesDiv).append($("<span>（"+num+"张预览图，可点击类 id 查看详情）</span>"));
                        if(oneClusterDiv) $("#clustering-result-div").append(oneClusterDiv);
		}
		<?php if(!$isOneCluster){//显示所有类时 ?>
		/* scroll监听函数 */
		function clusteringResultDivScroll(){
			var scrollTop = $("#clustering-result-div").scrollTop();
                        var seenHeight = $("#clustering-result-div").height();
                        var contentHeight = document.getElementById("clustering-result-div").scrollHeight;
                        if(scrollTop + seenHeight + 50 >= contentHeight){
				$("#clustering-result-div").off("scroll",clusteringResultDivScroll);
				var curClustersNum = $(".one-cluster-div").length;
				var clusterIdsStr = "";
				for(var i = curClustersNum; i < clusterIds.length; i++){
					if(i >= curClustersNum + onceClustersNum) break;
					if(clusterIdsStr == "") clusterIdsStr = clusterIds[i]["cluster_id"];
                                	else clusterIdsStr += ","+clusterIds[i]["cluster_id"];
				}
				$.ajax({url:"action_response.php",type:"post",async:"false",data:{"action":"getUrisByClusterIds","clusterIdsStr":clusterIdsStr},success:function(data){
                                	var dataArr = JSON.parse(data);
                                	showClusters(dataArr);
					$("#clustering-result-div").scroll(clusteringResultDivScroll);
                       		}});
                        }
		}
		<?php } ?>

		<?php if(!$isOneCluster){//显示所有类时 ?>
		/* 获取所有的类 */
		$.ajax({url:"action_response.php",type:"post",async:"false",data:{"action":"getAllClusterIds"},success:function(data){
			clusterIds = JSON.parse(data);
			var clusterIdsStr = "";
			for(var i = 0; i < clusterIds.length; i++){
				if(i >= onceClustersNum) break;
				if(clusterIdsStr == "") clusterIdsStr = clusterIds[i]["cluster_id"];
				else clusterIdsStr += ","+clusterIds[i]["cluster_id"];
			}
			$.ajax({url:"action_response.php",type:"post",async:"false",data:{"action":"getUrisByClusterIds","clusterIdsStr":clusterIdsStr},success:function(data){
				var dataArr = JSON.parse(data);
				showClusters(dataArr);//显示类
			}});
		}});
		/* 滚动监听 */
		$("#clustering-result-div").scroll(clusteringResultDivScroll);
		<?php }else{//显示一个类时 ?>
		var clusterId = <?= $_GET["clusterId"] ?>;
		var clusterIdsStr = clusterId;
		$.ajax({url:"action_response.php",type:"post",async:"false",data:{"action":"getUrisByClusterIds","clusterIdsStr":clusterIdsStr},success:function(data){
			var dataArr = JSON.parse(data);
			showClusters(dataArr);//显示类
			$(".cluster-name-a").removeAttr("href").removeAttr("target");
		}});
		<?php } ?>
	</script>
</body>
</html>
