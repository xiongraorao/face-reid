<?php 
	//header("Content-Type:text/html;charset=utf-8");
	$configFilePath = "config";//配置文件路径
	$ip = "192.168.1.11"; $user = "root"; $pw = "123456"; $db = "face_reid"; $port = "3306"; $table = "t_cluster2";//默认ip,user,pw,db,port和table

        $configFile = fopen($configFilePath,"r");
        if(!$configFile){
        	echo "config file lost";
                return;
        }
        while($row = fgets($configFile)){
        	$tmp = explode(":",$row);
		if($tmp[0] == "ip"){
			$ip = explode("\n",$tmp[1])[0];
		}else if($tmp[0] == "user"){
			$user = explode("\n",$tmp[1])[0];
		}else if($tmp[0] == "pw"){
			$pw = explode("\n",$tmp[1])[0];
                }else if($tmp[0] == "db"){
			$db = explode("\n",$tmp[1])[0];
                }else if($tmp[0] == "port"){
                        $port = explode("\n",$tmp[1])[0];
                }else if($tmp[0] == "table"){
			$table = explode("\n",$tmp[1])[0];
                }
        }
        fclose($configFile);

	$action = $_POST["action"];
	/* 获取所有类别 */
	if($action == "getAllClusterIds"){
		$mysqli = new mysqli($ip, $user, $pw, $db, $port);
		//$mysqli = new mysqli("192.168.1.6", "root", "123456", "face_reid", "13306");
		if(mysqli_connect_errno()){
    			die(mysqli_connect_error());
		}
		$sql = "select distinct cluster_id from $table order by cluster_id";
		$rs = $mysqli->query($sql);
		$rsArr = array();
		if($rs){
			$rsArr = mysqli_fetch_all($rs,MYSQLI_ASSOC);
			$rs->close();
		}
		$mysqli->close();
		echo json_encode($rsArr);
	}
	/* 通过cluster_id获取uri*/
	else if($action == "getUrisByClusterIds"){
		$clusterIdsStr = $_POST["clusterIdsStr"];
		$clusterIds = explode(",",$clusterIdsStr);
		$mysqli = new mysqli($ip, $user, $pw, $db, $port);
                if(mysqli_connect_errno()){
                        die(mysqli_connect_error());
                }
                $rsArr = array();
		for($i = 0; $i < count($clusterIds); $i++){
                	$sql = "select uri from $table where cluster_id='{$clusterIds[$i]}'";
                	$rs = $mysqli->query($sql);
                	if($rs){
				while($row = mysqli_fetch_row($rs)){
					$rsArr[] = "{$clusterIds[$i]} {$row["0"]}";
				}
                        	$rs->close();
                	}
		}
                $mysqli->close();
		echo json_encode($rsArr);
	}
	/* 修改表配置 */
	else if($action == "modifyTableConfig"){
		$newIp = $_POST["newIp"];
		$newUser = $_POST["newUser"];
		$newPw = $_POST["newPw"];
		$newDb = $_POST["newDb"];
		$newPort = $_POST["newPort"];
		$newTable = $_POST["newTable"];
		$configFile = fopen($configFilePath,"w+");
		if(!$configFile){
			echo "config file lost";
			return;
		}
		$configInfoArr = array();
		/*while($row = fgets($configFile)){
			$tmp = explode(":",$row);
                	$configInfoArr[$tmp[0]] = $tmp[1];
			echo "{$tmp[0] {$tmp[1]}}";
		}*/
		$configInfoArr["ip"] = $newIp;
		$configInfoArr["user"] = $newUser;
		$configInfoArr["pw"] = $newPw;
		$configInfoArr["db"] = $newDb;
		$configInfoArr["port"] = $newPort;
		$configInfoArr["table"] = $newTable;
		foreach($configInfoArr as $key => $value){
			fputs($configFile,"$key:$value\n");//每行末尾加入了\n
		}
		fclose($configFile);
		echo "ok";
	}
	else{
		echo "action failed";
	}
?>
