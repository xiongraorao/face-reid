<?php
	(isSet($_GET["clusterId"]))?$isOneCluster=true:$isOneCluster=false;//当前页面状态（显示所有类或显示一个类）
	(isSet($_GET["previewImgsNum"]))?$previewImgsNum=$_GET["previewImgsNum"]:$previewImgsNum=5;//预览图数
	$configFilePath = "config";
	$configInfoArr = array();
	$configFile = fopen($configFilePath,"r");
	if(!$configFile) die("config file lost");
	while($row = fgets($configFile)){
		$tmp = explode(":",$row);
		$configInfoArr[$tmp[0]] = $tmp[1];
	}
	fclose($configFile);
?>
<html>
<head>
	<title>clustering</title>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
	<!--<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">-->
	<style>
		body{
			padding:0 20px 20px 20px;
		}
		#clustering-result-div{
			width:100%;
			height:880px;
			overflow-y:auto;
			padding-bottom:20px;
		}
		.one-cluster-div{
		}
		.cluster-name-a{
			font-size:18px;
		}
		.one-cluster-images-div{
			padding:0 10px 0 10px;
		}
		.one-cluster-images-div img{
			margin:6px 6px 0 0;
			height:150px;
		}
		input{
			padding-left:5px;
			width:100px;
		}
		#config-modify-a{
			font-weight:normal;
		}
		.one-cluster-all-imgs-num-span{
			font-size:14px;
		}
	</style>
</head>
<body>
<h2>Clusters
<?php if(!$isOneCluster){//显示所有类时 ?>
<span style="font-size:14px">共<span id="clusters-total-span"></span>个类</span>&nbsp;&nbsp;&nbsp;<span style="font-size:14px">IP：<input id="ip-input" type="text" value="<?= $configInfoArr["ip"] ?>" />&nbsp;&nbsp;用户：<input id="user-input" type="text" value="<?= $configInfoArr["user"] ?>" />&nbsp;&nbsp;密码：<input id="pw-input" type="password" value="<?= $configInfoArr["pw"] ?>" />&nbsp;&nbsp;数据库：<input id="db-input" type="text" value="<?= $configInfoArr["db"] ?>" />&nbsp;&nbsp;端口：<input id="port-input" type="text" value="<?= $configInfoArr["port"] ?>" />&nbsp;&nbsp;表：<input id="table-input" type="text" value="<?= $configInfoArr["table"] ?>" />&nbsp;&nbsp;预览数：<input id="preview-num-input" type="number" value="<?= $previewImgsNum ?>" />&nbsp;<a id="config-modify-a" href="#" onclick="configModify()">修改并应用</a></span>
<?php } ?>
</h2>
	<div id="clustering-result-div"></div>
	
	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
	<!--<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>-->
	<script type="text/javascript">
		var clusterIds;//所有的类
		var clusterImgsArr;//类的图片数组（一个类时使用）
		var onceClustersNum = 10;//一次显示类的个数
		var previewImgsNum;//预览图的个数
		var onceOneClusterImgsNum = 100;//一次显示图片的个数（一个类时使用）
		var fileName = "clustering.php";//该文件的名字
		<?php if($isOneCluster){//显示一个类时 ?>
			var isOneCluster = true;
		<?php }else{//显示所有类时 ?>
			var isOneCluster = false;
		<?php } ?>

		/* 类点击函数 */
		function clusterClickFunc(obj){
			//var clusterId = $(obj).html().split(" ")[1];
			//alert(clusterId);
		}
		/* 显示类函数 */
		function showClusters(dataArr){
			var preClusterId = "",curClusterId = "", imgSrc = "", oneClusterDiv="", oneClusterImagesDiv="", imgsNum = -1, saveImgsNum = 0, oneClusterAllImgsNum = 0;
			(isOneCluster==true)?maxImgsNum=onceOneClusterImgsNum:maxImgsNum=previewImgsNum;
                        for(var i = 0; i < dataArr.length; i++){
                                curClusterId = dataArr[i].split(" ")[0];
                                imgSrc = dataArr[i].split(" ")[1];
                                if(curClusterId != preClusterId){
					//var num = 0;
					//(saveImgsNum > imgsNum)?num=saveImgsNum:num=imgsNum;
					//if(!isOneCluster && oneClusterImagesDiv) $(oneClusterImagesDiv).append($("<span>（"+num+"张预览图，可点击类 id 查看详情）</span>"));
                                        if(oneClusterDiv){
						$("#clustering-result-div").append(oneClusterDiv);
						$(oneClusterDiv).children("p").append($("<span class='one-cluster-all-imgs-num-span'>（共 "+oneClusterAllImgsNum+" 张）</span>"));
					}
					imgsNum = 0;
					oneClusterAllImgsNum = 0;
					saveImgsNum = 0;
                                        oneClusterDiv = $("<div class='one-cluster-div'><p><a class='cluster-name-a' title='点击查看类详情' onclick='clusterClickFunc(this)' href='"+fileName+"?clusterId="+curClusterId+"' target='_blank'>Cluster: "+curClusterId+"</a></p></div>");
                                        oneClusterImagesDiv = $("<div class='one-cluster-images-div'></div>");
                                        $(oneClusterDiv).append(oneClusterImagesDiv);
                                }
				if(imgsNum >= maxImgsNum){
					saveImgsNum = imgsNum;
					imgsNum = -1;
				}
				if(imgsNum == -1){
					oneClusterAllImgsNum++;
					continue;
				}
                                $(oneClusterImagesDiv).append($("<img src='"+imgSrc+"' />"));
                                preClusterId = curClusterId;
				imgsNum ++;
				oneClusterAllImgsNum++;
                        }
			//var num = 0;
			//(saveImgsNum > imgsNum)?num=saveImgsNum:num=imgsNum;
			//if(!isOneCluster && oneClusterImagesDiv) $(oneClusterImagesDiv).append($("<span>（"+num+"张预览图，可点击类 id 查看详情）</span>"));
                        if(oneClusterDiv){
				$("#clustering-result-div").append(oneClusterDiv);
				$(oneClusterDiv).children("p").append($("<span class='one-cluster-all-imgs-num-span'>（共 "+oneClusterAllImgsNum+" 张）</span>"));
			}
			if(isOneCluster && oneClusterDiv) $(".cluster-name-a").html($(".cluster-name-a").html()+"（共 "+dataArr.length+" 张）");
		}
		/* scroll监听函数 */
		function clusteringResultDivScroll(){
			var scrollTop = $("#clustering-result-div").scrollTop();
                        var seenHeight = $("#clustering-result-div").height();
                        var contentHeight = document.getElementById("clustering-result-div").scrollHeight;
                        if(scrollTop + seenHeight + 50 >= contentHeight){
				$("#clustering-result-div").off("scroll",clusteringResultDivScroll);
				if(!isOneCluster){//显示所有类时
					var curClustersNum = $(".one-cluster-div").length;
					var clusterIdsStr = "";
					for(var i = curClustersNum; i < clusterIds.length; i++){
						if(i >= curClustersNum + onceClustersNum) break;
						if(clusterIdsStr == "") clusterIdsStr = clusterIds[i]["cluster_id"];
                                		else clusterIdsStr += ","+clusterIds[i]["cluster_id"];
					}
					$.ajax({url:"action_response.php",type:"post",async:"false",data:{"action":"getUrisByClusterIds","clusterIdsStr":clusterIdsStr},success:function(data){
                                		var dataArr = JSON.parse(data);
                                		showClusters(dataArr);
						$("#clustering-result-div").scroll(clusteringResultDivScroll);
					}});
				}else{//显示一个类时
					var curImgsNum = $(".one-cluster-images-div img").length;
					if(curImgsNum < clusterImgsArr.length){//还有图片未显示
						for(var i = curImgsNum; i < clusterImgsArr.length; i++){
							if(i >= curImgsNum + onceOneClusterImgsNum) break;
                                			imgSrc = clusterImgsArr[i].split(" ")[1];
							$(".one-cluster-images-div").append($("<img src='"+imgSrc+"' />"));
						}
						$("#clustering-result-div").scroll(clusteringResultDivScroll);
					}
				}
                        }
		}
		<?php if(!$isOneCluster){//显示所有类时 ?>
		/* 配置修改函数 */
		function configModify(){
			var newIp = $("#ip-input").val();
			var newUser = $("#user-input").val();
			var newPw = $("#pw-input").val();
			var newDb = $("#db-input").val();
			var newPort = $("#port-input").val();
			var newTable = $("#table-input").val();
			$.ajax({url:"action_response.php",type:"post",async:"false",data:{"action":"modifyTableConfig","newIp":newIp,"newUser":newUser,"newPw":newPw,"newDb":newDb,"newPort":newPort,"newTable":newTable},success:function(data){
				if(data == "ok"){
					//window.location.reload();
					window.location.href=fileName+"?previewImgsNum="+$("#preview-num-input").val();
				}else{
					alert(data);
				}
                        }});
		}
		<?php } ?>

		<?php if(!$isOneCluster){//显示所有类时 ?>
		($("#preview-num-input").val() > 0)?previewImgsNum=$("#preview-num-input").val():previewImgsNum=Number.POSITIVE_INFINITY;
		/* 获取所有的类 */
		$.ajax({url:"action_response.php",type:"post",async:"false",data:{"action":"getAllClusterIds"},success:function(data){
			clusterIds = JSON.parse(data);
			$("#clusters-total-span").html(clusterIds.length);
			var clusterIdsStr = "";
			for(var i = 0; i < clusterIds.length; i++){
				if(i >= onceClustersNum) break;
				if(clusterIdsStr == "") clusterIdsStr = clusterIds[i]["cluster_id"];
				else clusterIdsStr += ","+clusterIds[i]["cluster_id"];
			}
			$.ajax({url:"action_response.php",type:"post",async:"false",data:{"action":"getUrisByClusterIds","clusterIdsStr":clusterIdsStr},success:function(data){
				var dataArr = JSON.parse(data);
				showClusters(dataArr);//显示类
			}});
		}});
		<?php }else{//显示一个类时 ?>
		var clusterId = "<?= $_GET["clusterId"] ?>";
		var clusterIdsStr = clusterId;
		$.ajax({url:"action_response.php",type:"post",async:"false",data:{"action":"getUrisByClusterIds","clusterIdsStr":clusterIdsStr},success:function(data){
			clusterImgsArr = JSON.parse(data);
			showClusters(clusterImgsArr);//显示类
			$(".cluster-name-a").removeAttr("href").removeAttr("target");
		}});
		<?php } ?>
		/* 滚动监听 */
		$("#clustering-result-div").scroll(clusteringResultDivScroll);
	</script>
</body>
</html>
